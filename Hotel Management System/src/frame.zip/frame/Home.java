//Title Of The Project :  "Hotel Management System"
//Author               :   Mathan Kumar T
//Created On           :   12.04.2022
//Last Modified Date   :   21.04.2022
//Reviewed By          :   
//Suggestion           : 	Change the naming convention in methods, variable, method name should be followed by verb.
//
//



package frame;

public class Home{
	
	public static void main(String[] args) {
	
	    new NewFrame();
        
	}
    
}

