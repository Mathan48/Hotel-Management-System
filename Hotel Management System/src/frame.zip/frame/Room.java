package frame;

public class Room {
	public String roomname;
	public String available;
	public String roomtype;
	public String numberofbeds;
	Room(String roomname, String available,String roomtype,String numberofbeds){
		this.roomname=roomname;
		this.available=available;
		this.roomtype=roomtype;
		this.numberofbeds=numberofbeds;		
	}
}
